package com.essalud.citas.model;

public enum EstadoCita {
    PENDIENTE,
    CONFIRMADA,
    CANCELADA,
    ATENDIDA
}
