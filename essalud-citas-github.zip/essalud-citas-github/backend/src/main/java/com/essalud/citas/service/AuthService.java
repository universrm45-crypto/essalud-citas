package com.essalud.citas.service;

import com.essalud.citas.dto.LoginRequest;
import com.essalud.citas.dto.LoginResponse;
import com.essalud.citas.model.Paciente;
import com.essalud.citas.repository.PacienteRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    private final PacienteRepository pacienteRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public AuthService(PacienteRepository pacienteRepository) {
        this.pacienteRepository = pacienteRepository;
    }

    public Optional<LoginResponse> login(LoginRequest request) {
        Optional<Paciente> pacienteOpt = pacienteRepository.findByDni(request.getDni());
        if (pacienteOpt.isEmpty()) {
            return Optional.empty();
        }
        Paciente paciente = pacienteOpt.get();
        if (!passwordEncoder.matches(request.getPassword(), paciente.getPasswordHash())) {
            return Optional.empty();
        }
        return Optional.of(new LoginResponse(
                paciente.getId(), paciente.getNombres(), paciente.getApellidos(), paciente.getDni()
        ));
    }
}
