package com.essalud.citas.repository;

import com.essalud.citas.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {
    List<Notificacion> findByPacienteIdOrderByCreatedAtDesc(Long pacienteId);
}
