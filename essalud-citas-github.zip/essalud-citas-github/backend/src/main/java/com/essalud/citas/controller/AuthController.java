package com.essalud.citas.controller;

import com.essalud.citas.dto.LoginRequest;
import com.essalud.citas.dto.LoginResponse;
import com.essalud.citas.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
        Optional<LoginResponse> resp = authService.login(request);
        if (resp.isPresent()) {
            return ResponseEntity.ok(resp.get());
        }
        return ResponseEntity.status(401).body(Map.of("error", "DNI o contraseña incorrectos"));
    }
}
