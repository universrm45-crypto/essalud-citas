package com.essalud.citas.repository;

import com.essalud.citas.model.Cita;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CitaRepository extends JpaRepository<Cita, Long> {
    List<Cita> findByPacienteIdOrderByFechaDescHoraDesc(Long pacienteId);
}
