package com.essalud.citas.controller;

import com.essalud.citas.dto.CitaRequest;
import com.essalud.citas.model.*;
import com.essalud.citas.repository.*;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/citas")
public class CitaController {

    private final CitaRepository citaRepository;
    private final PacienteRepository pacienteRepository;
    private final MedicoRepository medicoRepository;
    private final EspecialidadRepository especialidadRepository;
    private final HorarioRepository horarioRepository;
    private final NotificacionRepository notificacionRepository;

    public CitaController(CitaRepository citaRepository, PacienteRepository pacienteRepository,
                           MedicoRepository medicoRepository, EspecialidadRepository especialidadRepository,
                           HorarioRepository horarioRepository, NotificacionRepository notificacionRepository) {
        this.citaRepository = citaRepository;
        this.pacienteRepository = pacienteRepository;
        this.medicoRepository = medicoRepository;
        this.especialidadRepository = especialidadRepository;
        this.horarioRepository = horarioRepository;
        this.notificacionRepository = notificacionRepository;
    }

    @GetMapping
    public List<Cita> misCitas(@RequestParam Long pacienteId) {
        return citaRepository.findByPacienteIdOrderByFechaDescHoraDesc(pacienteId);
    }

    @PostMapping
    public ResponseEntity<?> crear(@Valid @RequestBody CitaRequest req) {
        Paciente paciente = pacienteRepository.findById(req.getPacienteId())
                .orElse(null);
        Medico medico = medicoRepository.findById(req.getMedicoId()).orElse(null);
        Especialidad especialidad = especialidadRepository.findById(req.getEspecialidadId()).orElse(null);

        if (paciente == null || medico == null || especialidad == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Paciente, medico o especialidad no existen"));
        }

        Cita cita = new Cita();
        cita.setPaciente(paciente);
        cita.setMedico(medico);
        cita.setEspecialidad(especialidad);
        cita.setFecha(req.getFecha());
        cita.setHora(req.getHora());
        cita.setMotivo(req.getMotivo());
        cita.setEstado(EstadoCita.CONFIRMADA);

        if (req.getHorarioId() != null) {
            Horario horario = horarioRepository.findById(req.getHorarioId()).orElse(null);
            if (horario != null) {
                horario.setDisponible(false);
                horarioRepository.save(horario);
                cita.setHorario(horario);
            }
        }

        Cita guardada = citaRepository.save(cita);

        // Genera automaticamente una notificacion de confirmacion
        Notificacion notif = new Notificacion();
        notif.setPaciente(paciente);
        notif.setIcono("check");
        notif.setTitulo("Cita confirmada");
        notif.setMensaje("Tu cita con " + medico.getNombres() + " " + medico.getApellidos()
                + " (" + especialidad.getNombre() + ") fue confirmada para el " + req.getFecha() + ".");
        notificacionRepository.save(notif);

        return ResponseEntity.ok(guardada);
    }

    @PutMapping("/{id}/cancelar")
    public ResponseEntity<?> cancelar(@PathVariable Long id) {
        return citaRepository.findById(id).map(cita -> {
            cita.setEstado(EstadoCita.CANCELADA);
            citaRepository.save(cita);
            return ResponseEntity.ok(cita);
        }).orElse(ResponseEntity.notFound().build());
    }
}
