package com.essalud.citas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EssaludCitasApplication {
    public static void main(String[] args) {
        SpringApplication.run(EssaludCitasApplication.class, args);
    }
}
