package com.essalud.citas.controller;

import com.essalud.citas.model.Medico;
import com.essalud.citas.repository.MedicoRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medicos")
public class MedicoController {

    private final MedicoRepository medicoRepository;

    public MedicoController(MedicoRepository medicoRepository) {
        this.medicoRepository = medicoRepository;
    }

    @GetMapping
    public List<Medico> listar(@RequestParam(required = false) Long especialidadId) {
        if (especialidadId != null) {
            return medicoRepository.findByEspecialidadId(especialidadId);
        }
        return medicoRepository.findAll();
    }
}
