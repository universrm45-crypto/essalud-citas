package com.essalud.citas.controller;

import com.essalud.citas.model.Notificacion;
import com.essalud.citas.repository.NotificacionRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notificaciones")
public class NotificacionController {

    private final NotificacionRepository notificacionRepository;

    public NotificacionController(NotificacionRepository notificacionRepository) {
        this.notificacionRepository = notificacionRepository;
    }

    @GetMapping
    public List<Notificacion> listar(@RequestParam Long pacienteId) {
        return notificacionRepository.findByPacienteIdOrderByCreatedAtDesc(pacienteId);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        notificacionRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    public ResponseEntity<?> eliminarTodas(@RequestParam Long pacienteId) {
        notificacionRepository.deleteAll(notificacionRepository.findByPacienteIdOrderByCreatedAtDesc(pacienteId));
        return ResponseEntity.noContent().build();
    }
}
