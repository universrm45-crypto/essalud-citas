package com.essalud.citas.dto;

public class LoginResponse {
    private Long pacienteId;
    private String nombres;
    private String apellidos;
    private String dni;

    public LoginResponse(Long pacienteId, String nombres, String apellidos, String dni) {
        this.pacienteId = pacienteId;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dni = dni;
    }

    public Long getPacienteId() { return pacienteId; }
    public String getNombres() { return nombres; }
    public String getApellidos() { return apellidos; }
    public String getDni() { return dni; }
}
